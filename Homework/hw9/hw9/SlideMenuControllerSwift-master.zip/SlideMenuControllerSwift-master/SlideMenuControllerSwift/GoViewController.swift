//
//  GoViewController.swift
//  SlideMenuControllerSwift
//

//

import UIKit

class GoViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarItem()
    }
}
