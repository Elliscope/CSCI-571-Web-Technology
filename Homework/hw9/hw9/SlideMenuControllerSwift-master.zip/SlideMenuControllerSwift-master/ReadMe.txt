ReadMe


The code is for CSCI 571 hw9.

The code utilized some tool from SlideMenuController github. Thanks author for providing those frameworks.

Mingzhe Fang
5301084138